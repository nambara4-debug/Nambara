package pt.sergio.patches.smartlauncher

import app.morphe.patcher.Fingerprint
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.patch.AppTarget
import app.morphe.patcher.patch.Compatibility
import app.morphe.patcher.patch.bytecodePatch

private const val EXTENSION = "Lpt/sergio/extension/smartlauncher/Force60Hz;"

private val smartLauncherApplicationOnCreate = Fingerprint(
    definingClass = "Lginlemon/flower/App;",
    name = "onCreate",
    returnType = "V",
    parameters = emptyList(),
)

private val smartLauncherCompatibility = Compatibility(
    name = "Smart Launcher",
    packageName = "ginlemon.flowerfree",
    appIconColor = 0x000000,
    targets = listOf(AppTarget("6.6 build 016")),
)

@Suppress("unused")
val force60HzPatch = bytecodePatch(
    name = "Force 60 Hz",
    description = "Requests 60 Hz while Smart Launcher is in the foreground.",
    default = false,
) {
    compatibleWith(smartLauncherCompatibility)
    extendWith("extensions/extension.mpe")

    execute {
        smartLauncherApplicationOnCreate.method.addInstructions(
            1,
            """
                invoke-static {p0}, $EXTENSION->install(Landroid/app/Application;)V
            """.trimIndent(),
        )
    }
}
