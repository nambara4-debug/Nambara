group = "pt.sergio"

patches {
    // TODO: Update this section with your project details.
    about {
        name = "Sérgio's Morphe Patches"
        description = "Personal Morphe patches for Android apps"
        source = "https://github.com/nambara4-debug/Nambara"
        author = "Sérgio Falcão"
        contact = "na"
        website = "https://github.com/nambara4-debug/Nambara"
        license = "GPLv3"
    }
}

// Separate configuration so gson is available at runtime for the
// generatePatchesList task but never bundled into the APK.
val patchListGeneratorClasspath = configurations.create("patchListGeneratorClasspath")

dependencies {
    compileOnly(libs.gson)
    patchListGeneratorClasspath(libs.gson)
}

tasks {
    register<JavaExec>("generatePatchesList") {
        description = "Build patch with patch list"

        dependsOn(build)

        classpath = sourceSets["main"].runtimeClasspath + patchListGeneratorClasspath
        mainClass.set("util.PatchListGeneratorKt")
    }

    // Used by gradle-semantic-release-plugin.
    publish {
        dependsOn("generatePatchesList")
    }
}
