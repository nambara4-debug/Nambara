extension {
    name = "extensions/extension.mpe"
}

android {
    namespace = "pt.sergio.extension"
}
