package pt.sergio.extension.smartlauncher;

import android.app.Activity;
import android.app.Application;
import android.os.Bundle;
import android.view.Display;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;

/** Requests the native 60 Hz display mode for every Smart Launcher activity. */
@SuppressWarnings("unused")
public final class Force60Hz {
    private static final float TARGET_HZ = 60.0f;
    private static boolean installed;

    private Force60Hz() {}

    public static void install(final Application application) {
        try {
            if (application == null || installed) return;
            installed = true;
            application.registerActivityLifecycleCallbacks(new Application.ActivityLifecycleCallbacks() {
                @Override public void onActivityCreated(Activity activity, Bundle state) { apply(activity); }
                @Override public void onActivityResumed(Activity activity) { apply(activity); }
                @Override public void onActivityStarted(Activity activity) {}
                @Override public void onActivityPaused(Activity activity) {}
                @Override public void onActivityStopped(Activity activity) {}
                @Override public void onActivitySaveInstanceState(Activity activity, Bundle state) {}
                @Override public void onActivityDestroyed(Activity activity) {}
            });
        } catch (Throwable ignored) {}
    }

    private static void apply(final Activity activity) {
        try {
            if (activity == null) return;
            applyNow(activity);
            Window window = activity.getWindow();
            if (window == null) return;
            View decor = window.getDecorView();
            if (decor == null) return;
            Runnable retry = new Runnable() {
                @Override public void run() {
                    applyNow(activity);
                }
            };
            decor.post(retry);
            decor.postDelayed(retry, 250L);
            decor.postDelayed(retry, 1000L);
        } catch (Throwable ignored) {}
    }

    private static void applyNow(Activity activity) {
        try {
            Window window = activity.getWindow();
            if (window == null) return;
            WindowManager.LayoutParams attrs = window.getAttributes();
            if (attrs == null) return;
            attrs.preferredRefreshRate = TARGET_HZ;
            int modeId = findNative60HzMode(activity);
            if (modeId != 0) attrs.preferredDisplayModeId = modeId;
            window.setAttributes(attrs);
        } catch (Throwable ignored) {}
    }

    private static int findNative60HzMode(Activity activity) {
        try {
            Display display = activity.getDisplay();
            if (display == null) return 0;
            Display.Mode current = display.getMode();
            for (Display.Mode mode : display.getSupportedModes()) {
                if (mode.getPhysicalWidth() == current.getPhysicalWidth()
                        && mode.getPhysicalHeight() == current.getPhysicalHeight()
                        && Math.abs(mode.getRefreshRate() - TARGET_HZ) < 0.5f) {
                    return mode.getModeId();
                }
            }
        } catch (Throwable ignored) {}
        return 0;
    }
}
