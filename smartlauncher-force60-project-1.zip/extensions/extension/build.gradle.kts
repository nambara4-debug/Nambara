extension {
    name = "extensions/extension.mpe"
}

android {
    namespace = "pt.sergio.extension"

    // A extensão só usa APIs Android existentes. A desugaring de bibliotecas
    // acrescentava mais de mil classes auxiliares ao MPE e fazia o Morphe
    // falhar ao fundi-lo com o APK ("Collection is empty").
    compileOptions {
        isCoreLibraryDesugaringEnabled = false
    }
}
